module.exports = {
    jwt: {
        secret: "default", // É utilizado para poder gerar o Token
        expiresIn: "1d"
    }
}