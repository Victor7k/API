const fs = require("fs")
const path = require("path")
const uploadConfig = require("../configs/upload")

class DiskStorage {
    async saveFile(file) {
        await fs.promises.rename(
            path.resolve(uploadConfig.TMP_FOLDER, file), // A imagem estava na pasta temporária esperando o backend decidir o q fazer com ela
            path.resolve(uploadConfig.UPLOADS_FOLDER, file) // Na hora de salvar o arquivo então mandamos a imagem pra pasta de uploads
        );

        return file;
    }

    async deleteFile(file) {
        const filePath = path.resolve(uploadConfig.UPLOADS_FOLDER, file);
        try {
            await fs.promises.stat(filePath);
        } catch {
            return;
        }

        await fs.promises.unlink(filePath); // Vai deletar.
    }
}

module.exports = DiskStorage;