const knex = require("../database/knex")
const AppError = require("../utils/AppError")
const DiskStorage = require("../providers/DiskStorage")

class UserAvatarController {
    async update(request, response) {
        const user_id = request.user.id
        const avatarFilename = request.file.filename

        const diskStorage = new DiskStorage()

        // Vai buscar os dados usuário para poder atualizar o avatar dele
        const user = await knex("users")
            .where({ id: user_id }).first() // Vai pegar o id do usuário q é igual ao user_id.

            if(!user) {
                throw new AppError("Somente usuários autenticados podem mudar o avatar", 401)
            }

            if(user.avatar) {
                await diskStorage.deleteFile(user.avatar) // Vai deletar a foto antiga do avatar
            }

            const filename = await diskStorage.saveFile(avatarFilename) // Está pegando a nova foto
            user.avatar = filename // Está colocando a nova imagem no avatar.

            await knex("users").update(user).where({ id: user_id })

            return response.json(user)
    }
}

module.exports = UserAvatarController