const { verify } = require("jsonwebtoken")
const AppError = require("../utils/AppError")
const authConfig = require("../configs/auth")

function ensureAuthenticated(request, response, next) {
    const authHeader = request.headers.authorization

    if(!authHeader) {
        throw new AppError("JWT Token não informado", 401)
    }

    // Está quebrando o texto e pegando a segunda posição do Array e passando para variável token.
    const [, token] = authHeader.split(" ") // A primeira posição do Vetor está omitida porque senão iria mostrar o texto "Bearer" e então o Token, mas nesse caso só queremos o Token.

    try { // user_id serve como alias do sub, mas tbm referencia q pegamos especificamente o id do usuário do Token.
        const { sub: user_id } = verify(token, authConfig.jwt.secret) // O sub é o conteúdo que está armazenado no Token de Autenticação.

        request.user = {
            id: Number(user_id),
        }

        return next()
    } catch(e) {
        throw new AppError("JWT Token inválido", 401)
    }
}

module.exports = ensureAuthenticated