// Vai ser usado para padronizar o tipo de mensagem q vai aparecer quando tiver algum tipo de exceção.
class AppError {
    message;
    statusCode;

    constructor(message, statusCode = 400) { // Valor padrão do statusCode é 400 caso ele não seja informado.
        this.message = message;
        this.statusCode = statusCode;
    }
}

module.exports = AppError;