const sqliteConnection = require('../../sqlite')
const createUsers = require('./createUsers')

async function migrationsRun() {
    const schemas = [ // Vai se referir as tabelas q o Banco vai ter.
        createUsers
    ].join('') // Vai juntas todas as tabelas.

    sqliteConnection()
        .then(db => db.exec(schemas)) // Vai executar as tabelas.
        .catch(error => console.log(error))
}

module.exports = migrationsRun