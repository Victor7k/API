// Este arquivo vai se conectar com o SQLite
const sqlite3 = require('sqlite3') // Este é o Drive que vai estabelecer a comunicação com a Base de Dados.
const sqlite = require('sqlite') // Esse é responsável por conectar.
const path = require('path')

/*
    É essencial ser uma função assíncrona 
        pois o arquivo 'database.db' pode não existir na hora de executar o código.
*/
async function sqliteConnection() {
    const database = await sqlite.open({
        // Objeto com configurações da conexão
        filename: path.resolve(__dirname, "..", "database.db"), // Vai criar o arquivo numa pasta atrás caso não exista.
        // Drive de conexão a ser utilizado
        driver: sqlite3.Database
    })

    return database
}

module.exports = sqliteConnection