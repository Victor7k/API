const config = require('../../../knexfile');
const knex = require('knex');

const connection = knex(config.development); // Está passando quais são as configurações de conexão.

module.exports = connection;