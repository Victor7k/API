exports.up = knex => knex.schema.createTable("links", table => {
    table.increments("id");
    table.text("url").notNullable(); // Não aceita valor nulo.

    // Se você deletar a Nota que uma ou mais Tags estão vinculadas então automaticamente ele vai deletar todas essas Tags em cascata.
    table.integer("note_id").references("id").inTable("notes").onDelete("CASCADE");
    
    table.timestamp("created_at").default(knex.fn.now());
});

exports.down = knex => knex.schema.dropTable("links");