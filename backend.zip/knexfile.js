// O 'path' vai lidar com o endereço do arquivo independente do Sistema Operacional usado.
const path = require('path');

module.exports = {
  development: {
    client: 'sqlite3', // Aqui está dizendo qual é o tipo de client q vamos utilizar para se conectar com o banco de dados. 
    connection: {
      filename: path.resolve(__dirname, 'src', 'database', 'database.db') // Aqui vai formar o caminho, partindo desta pasta até chegar no arquivo database.db
    },
    pool: { // Tudo que estiver aqui dentro será executado no momento de conexão com o Banco de Dados. 
      afterCreate: (conn, cb) => conn.run("PRAGMA foreign_keys = ON", cb)
    },
    migrations: {
      directory: path.resolve(__dirname, 'src', 'database', 'knex', 'migrations')
    },
    useNullAsDefault: true
  }
};